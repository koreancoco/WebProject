package com.demo.controller;/**
  *ClassNmae:  AppRequest
  *Description:  TODO
  *@author  MasonWu
  *@date  2019/6/1 10:40
  *@version  1.0
  *Copyright (c) 2018-2020 Koreancoco All Rights Reserved.
  **/
public class AppRequest {

}
